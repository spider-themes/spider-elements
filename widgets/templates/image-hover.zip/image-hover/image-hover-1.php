<figure class="sp_image_hover">
        <img src="<?php echo $img_attachment_meta['src']; ?>" alt="<?php echo $img_attachment_meta['alt']; ?>">
    <figcaption>
        <h3><?php echo $img_attachment_meta['title']; ?></h3>
        <p><?php echo $img_attachment_meta['caption']; ?></p>
        <a href="#"></a>
    </figcaption>			
</figure>